// DANIT LEAN
// CS 355
// HADERMAN M.
// PROJECT 1


//================================================================================================

// Module dependencies

var express    = require('express'),
    mysql      = require('mysql');
//================================================================================================

// Application initialization

var connection = mysql.createConnection({
    host     : 'cwolf.cs.sonoma.edu',
    user     : 'dlean',
    password : '3728236'
});

var app = module.exports = express.createServer();

//================================================================================================

// Database setup

connection.query('USE dlean', function (err) {
    if (err) throw err;
});

// Configuration

app.use(express.bodyParser());

//================================================================================================

// Main page with two links to view the table and drop down menu

var htmlHeader = '<html><head><title>Basketball Database</title></head><body>';
var htmlFooter = '</body></html>';

function handleError(res, error) {
    console.log(error);
    res.send(error.toString());
}

function buildUserView(result) {

    // Build the HTML table from the data in baskeball table
    var responseHTML = htmlHeader + '<h1>PLAYER INFO.</h1>';
	
    //Dynamic populating rows from the records returned
    for (var i=0; i < result.length; i++) {
        responseHTML += '<ul><li>NO.:--------  ' + result[i].Num + '</li>' +
	    '<li>Name:------  ' + result[i].Name + '</li>' +
	    '<li>Position:--- ' + result[i].Position + '</li>' +
	    '<li>Age:-------- ' + result[i].Age + '</li>' +
            '<li>Height:-----  ' + result[i].Height + '</li>' +
	    '<li>Weight:----  ' + result[i].Weight + '</li>' +
            '<li>College:----  ' + result[i].College + '</li></ul>'
    }
    responseHTML += htmlFooter;

    return responseHTML;
}

app.get('/', function(req, res) {
    req.query.name
    res.send('<html><head><title>BASKETBALL</title></head><body><h1> GSW MANAGEMENT</h1>' +
            '<a href="/teamroster/add">Add Player To Team Roster</a><br/> <br />' +
	    '<a href="/starters/view/table">Starting Lineup</a>' +
            '<br/><br/>' +
            '<a href="/teamroster/view/table">View Team Roster</a>' +
            '<br /><br />' +
	    '<a href="/seasonstats/view/table">View Season Statistics</a>' +
            '<br /><br />' +
	    '<a href="/gamestats/view/table">View Game Statistics</a>' +
            '<br /><br />' +
            '<a href="/teamroster/compare/points">View Player Season vs Game Points</a>' +
            '<br /><br />' +
	    '<a href="/teamroster/compare/minutes">View Player Season vs Game Minutes</a>' +
            '<br /><br />'
    );
});

//================================================================================================

// HTML with data populated from the Team_roster table

app.get('/teamroster/view/table', function (req, res) {

    var myQry = 'SELECT * FROM Team_roster';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                // Build the HTML table from the data in the Team Roster
                var responseHTML = '<h1>TEAM ROSTER</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>NO.</th>' +
                    '<th>NAME</th>' +
                    '<th><!-- More Info Column --></th>' +
                    '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
		'<br><a href="/teamroster/add">ADD PLAYER</a><br/><br/>'	
		'</tr>';
                //Dynamic populating rows from the records returned
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Num + '</td>' +
                        '<td>' + result[i].Name + '</td>' +
                        '<td><a href="/teamroster/?Num=' + result[i].Num + '">More Info.</a>' +
                        '<td><a href="/teamroster/edit?Num=' + result[i].Num + '">Edit</a>' +
                        '<td><a href="/teamroster/delete?Num=' + result[i].Num + '">Delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});

//================================================================================================
// HTML with data populated from the Starters table
app.get('/starters/view/table', function (req, res) {

    var myQry = 'SELECT * FROM Starters';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
	       var responseHTML = '<h1>TEAM STARTING LINEUP</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>PositionID</th>' +
		    '<th>Position</th>' + 
                    '<th>Starter</th>' +
                    '<th>Second</th>' +
		    '<th>Third</th>' +
                    '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
        	 '<br><a href="/starters/add">ADD STARTING LINEUP</a><br/><br/>'		
	        '</tr>';
		for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].PositionID + '</td>' +
                        '<td>' + result[i].Position + '</td>' +
		        '<td>' + result[i].Starter + '</td>' +
			'<td>' + result[i].Second + '</td>' +
			'<td>' + result[i].Third + '</td>' +
                        '<td><a href="/starters/edit?PositionID=' + result[i].PositionID + '">Edit</a>' +
                        '<td><a href="/starters/delete?PositionID=' + result[i].PositionID + '">Delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});

//================================================================================================
// HTML with data populated from the Season_stats table
app.get('/seasonstats/view/table', function (req, res) {

    var myQry = 'SELECT * FROM Season_stats';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
               var responseHTML = '<h1>PLAYER SEASON STATISTICS</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th> No. </th>' +
                    '<th>Name</th>' +
		    '<th>MPG</th>' +
                    '<th>FGP</th>' +
		    '<th>3PP</th>' +
		    '<th>APG</th>' +
		    '<th>RPG</th>' +
		    '<th>SPG</th>' +
                    '<th>PPG</th>' +
         	    '<th>Player Info</th>' +
	            '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
		'<br><a href="/seasonstats/add">ADD PLAYER</a><br/><br/>'
                '</tr>';
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Num + '</td>' +
                        '<td>' + result[i].Name + '</td>' +
			'<td>' + result[i].MPG + '</td>' +
                    	'<td>' + result[i].FGP + '</td>' +
		        '<td>' + result[i].ThreePP + '</td>' +
                        '<td>' + result[i].APG + '</td>' +
                        '<td>' + result[i].RPG + '</td>' +
                        '<td>' + result[i].SPG + '</td>' +
			'<td>' + result[i].PPG + '</td>' +
			'<td><a href="/teamroster/?Num=' + result[i].Num + '">More Info.</a>' +
			'<td><a href="/seasonstats/edit?Num=' + result[i].Num + '">Edit</a>' +
                        '<td><a href="/seasonstats/delete?Num=' + result[i].Num + '">Delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});


//================================================================================================

// HTML with data populated from the Game_stats table
app.get('/gamestats/view/table', function (req, res) {

    var myQry = 'SELECT * FROM Game_stats';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
               var responseHTML = '<h1>PLAYER GAME STATISTICS</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th> No. </th>' +
                    '<th>Name</th>' +
                    '<th>Minutes</th>' +
                    '<th>FG</th>' +
                    '<th>3P</th>' +
                    '<th>Assists</th>' +
                    '<th>Rebounds</th>' +
                    '<th>Steals</th>' +
		    '<th>Fouls</th>' +
                    '<th>Turnovers</th>' +
                    '<th>Points</th>' +
                    '<th>Player Info</th>' +
                    '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
                '<br><a href="/gamestats/add">ADD PLAYER</a><br/><br/>'
                '</tr>';
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Num + '</td>' +
                        '<td>' + result[i].Name + '</td>' +
                        '<td>' + result[i].Minutes + '</td>' +
                        '<td>' + result[i].FG + '</td>' +
                        '<td>' + result[i].ThreeP + '</td>' +
                        '<td>' + result[i].Assists + '</td>' +
             		'<td>' + result[i].Rebounds + '</td>' +
                        '<td>' + result[i].Steals + '</td>' +
                        '<td>' + result[i].Fouls + '</td>' +
                        '<td>' + result[i].Turnovers + '</td>' +
	                '<td>' + result[i].Points + '</td>' +
                        '<td><a href="/teamroster/?Num=' + result[i].Num + '">More Info.</a>' +
                        '<td><a href="/gamestats/edit?Num=' + result[i].Num + '">Edit</a>' +
                        '<td><a href="/gamestats/delete?Num=' + result[i].Num + '">Delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});





//================================================================================================


// HTML with data populated from the Game_stats, Team_roster, and Season_stats table for points
app.get('/teamroster/compare/points', function (req, res) {

    var myQry = 'select Season_stats.Num, Team_roster.Position, Season_stats.Name, Season_stats.PPG, Game_stats.Points from Season_stats JOIN Game_stats on Season_stats.Num=Game_stats.Num join Team_roster on Team_roster.Num=Season_stats.Num;';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
               var responseHTML = '<h1>PLAYER SEASON VS GAME POINTS</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>NO.</th>' +
                    '<th>Position</th>' +
	            '<th>Name</th>' +
                    '<th>Season Average Points Per Game</th>' +
                    '<th>Points Scored In Game </th>' +
                    '<th><!--  Info Column --></th>' +
                '</tr>';
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Num + '</td>' +
                        '<td>' + result[i].Position + '</td>' +
		        '<td>' + result[i].Name + '</td>' +
                        '<td>' + result[i].PPG + '</td>' +
                        '<td>' + result[i].Points + '</td>' +
        		'<td><a href="/teamroster/?Num=' + result[i].Num + '">More Info.</a>' +                
			'</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});




//================================================================================================


// HTML with data populated from the Game_stats, Team_roster, and Season_stats table for minutes

app.get('/teamroster/compare/minutes', function (req, res) {

    var myQry = 'select Season_stats.Num, Team_roster.Position, Season_stats.Name, Season_stats.MPG, Game_stats.Minutes from Season_stats JOIN Game_stats on Season_stats.Num=Game_stats.Num join Team_roster on Team_roster.Num=Season_stats.Num;';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
               var responseHTML = '<h1>PLAYER SEASON VS GAME MINUTES</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>NO.</th>' +
             	    '<th>Position</th>' +
	            '<th>Name</th>' +
                    '<th>Season Average Minutes Per Game</th>' +
                    '<th>Minutes Played In Game </th>' +
                    '<th><!--  Info Column --></th>' +
                '</tr>';
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Num + '</td>' +
                        '<td>' + result[i].Position + '</td>' +
		        '<td>' + result[i].Name + '</td>' +
                        '<td>' + result[i].MPG + '</td>' +
                        '<td>' + result[i].Minutes + '</td>' +
                        '<td><a href="/teamroster/?Num=' + result[i].Num + '">More Info.</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});


//================================================================================================

// Display information about a Team_roster when given their Player Number
app.get('/teamroster/', function (req, res) {

    var myQry = 'SELECT * FROM Team_roster WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send(buildUserView(result));
            }
        }
    );
});


//================================================================================================

// Display a form that allows user to enter Team Roster
app.get('/teamroster/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert Player Into Team Roster</h1>' +
        '<form action="/teamroster/insert" method="GET">' +
        '<input type="hidden" name="Num" id="Num" />' + 
        '<label for="Name">Name....</label> <input type="text" name="Name" id="Name" /><br/><br />' +
	'<label for="Position">Position</label> <input type="text" name="Position" id="Position" /><br/><br />' +
	'<label for="Age">Age......</label> <input type="text" name="Age" id="Age" /><br/><br />' +
	'<label for="Height">Height..</label> <input type="text" name="Height" id="Height" /><br/><br />' +
	'<label for="Weight">Weight.</label> <input type="text" name="Weight" id="Weight" /><br/><br />' +
        '<label for="College">College</label> <input type="text" name="College" id="College" /<br/><br/><br />' +
        '<input type="submit" />' +
        '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});


//================================================================================================
// Display a form that allows user to enter Starters
app.get('/starters/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert Into Team Starting Lineup</h1>' +
        '<form action="/starters/insert" method="GET">' +
        '<label for="PositionID">PositionID..</label> <input type="text" name="PositionID" id="PositionID" /><br/><br />' +
        '<label for="Position">Position.....</label> <input type="text" name="Position" id="Position" /><br/><br />' +
        '<label for="Starter">Starter.......</label> <input type="text" name="Starter" id="Starter" /><br/><br />' +
        '<label for="Second">Second......</label> <input type="text" name="Second" id="Second" /><br/><br />' +
        '<label for="Third">Third.........</label> <input type="text" name="Third" id="Third" /><br/><br />' +
        '<input type="submit" />' +
        '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});


//================================================================================================
// Display a form that allows user to enter Season_stats
app.get('/seasonstats/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert Player Into Season Stats</h1>' +
        '<form action="/seasonstats/insert" method="GET">' +
        '<label for="Name">NO......</label><input type="text" name="Num" id="Num" /><br/><br />' +
        '<label for="Name">Name.</label> <input type="text" name="Name" id="Name" /><br/><br />' +
        '<label for="MPG">MPG..</label> <input type="text" name="MPG" id="MPG" /><br/><br />' +
        '<label for="FGP">FGP...</label> <input type="text" name="FGP" id="FGP" /><br/><br />' +
        '<label for="ThreePP">3PP....</label> <input type="text" name="ThreePP" id="ThreePP" /><br/><br />' +
        '<label for="APG">APG..</label> <input type="text" name="APG" id="APG" /><br/><br />' +
        '<label for="RPG">RPG...</label> <input type="text" name="RPG" id="RPG" /><br/><br />' +
	'<label for="SPG">SPG...</label> <input type="text" name="SPG" id="SPG" /><br/><br />' +
        '<label for="PPG">PPG...</label> <input type="text" name="PPG" id="PPG" /<br/><br/><br />' +
        '<input type="submit" />' +
        '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});


//================================================================================================
// Display a form that allows user to enter Game_stats
app.get('/gamestats/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert Player Into Game Stats</h1>' +
        '<form action="/gamestats/insert" method="GET">' +
        '<label for="Name">NO..............</label><input type="text" name="Num" id="Num" /><br/><br />' +
        '<label for="Name">Name.........</label> <input type="text" name="Name" id="Name" /><br/><br />' +
        '<label for="Minutes">Minutes......</label> <input type="text" name="Minutes" id="Minutes" /><br/><br />' +
        '<label for="FG">FG..............</label> <input type="text" name="FG" id="FG" /><br/><br />' +
        '<label for="ThreeP">ThreeP.......</label> <input type="text" name="ThreeP" id="ThreeP" /><br/><br />' +
        '<label for="Assists">Assists........</label> <input type="text" name="Assists" id="Assists" /><br/><br />' +
        '<label for="Rebounds">Rebounds...</label> <input type="text" name="Rebounds" id="Rebounds" /<br/><br/><br />' +
	'<label for="Steals">Steals..........</label> <input type="text" name="Steals" id="Steals" /><br/><br />' +
        '<label for="Fouls">Fouls..........</label> <input type="text" name="Fouls" id="Fouls" /<br/><br/><br />' +
	'<label for="Turnovers">Turnovers...</label> <input type="text" name="Turnovers" id="Turnovers" /><br/><br />' +
        '<label for="Points">Points.........</label> <input type="text" name="Points" id="Points" /<br/><br/><br />' +	
        '<input type="submit" />' +
        '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});



//================================================================================================


// Display a form that allows user to enter Team Roster
app.get('/teamroster/insert', function(req, res){

    var myQry = 'INSERT INTO Team_roster (Name, Position, Age, Height, Weight, College) VALUES (' +
        '\'' + req.query.Name + '\', ' +
        '\'' + req.query.Position + '\', ' +
	'\'' + req.query.Age + '\', ' +
	'\'' + req.query.Height + '\', ' +
	'\'' + req.query.Weight + '\', ' +
        '\'' + req.query.College + '\'' +
        ')';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM Team_roster WHERE Num = ' + result.insertId,
                    function (err, result) {
                        if (err) {
                            handleError(res, err);
                        }
                        else if(result.length == 1) {
                            res.send(buildUserView(result));
                        }
                        else {
                            res.send('NO PLAYER FOUND FOR THAT PLAYER NUMBER.');
                        }
                  });
             }
        }
    );
});


//================================================================================================
// Display a form that allows user to enter Starters
app.get('/starters/insert', function(req, res){

    var myQry = 'INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUES (' +
        '\'' + req.query.PositionID + '\', ' +
        '\'' + req.query.Position + '\', ' +
        '\'' + req.query.Starter + '\', ' +
        '\'' + req.query.Second + '\', ' +
        '\'' + req.query.Third + '\'' +
        ')';

    console.log(myQry);

	  connection.query(myQry,
        function (err, result) {
            if (err) {
                     res.send('STARTING LINE UP POSITION ID ALREADY EXISTS.');
            }
            else {  res.send('STARTING LINEUP INSERTED  SUCCESSFULLY!'); }
              });
            }
    );

//================================================================================================

// Display a form that allows user to enter Season_stats
app.get('/seasonstats/insert', function(req, res){

    var myQry = 'INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUES (' +
        '\'' + req.query.Num + '\', ' +
	'\'' + req.query.Name + '\', ' +
        '\'' + req.query.MPG + '\', ' +
        '\'' + req.query.FGP + '\', ' +
        '\'' + req.query.ThreePP + '\', ' +
        '\'' + req.query.APG + '\', ' +
	'\'' + req.query.RPG + '\', ' +
        '\'' + req.query.SPG + '\', ' +
        '\'' + req.query.PPG + '\'' +
        ')';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
	             res.send('YOU CAN ONLY ADD NEW EXISTING PLAYER NO. FROM THE TEAM ROSTER. TO THE SEASON STATS. ');
            }
            else {  res.send('PLAYER INSERTED INTO SEASON STATS SUCCESSFULLY!'); }
              });
            }
    );


//================================================================================================
// Display a form that allows user to enter Game_stats
app.get('/gamestats/insert', function(req, res){

    var myQry = 'INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUES (' +
        '\'' + req.query.Num + '\', ' +
        '\'' + req.query.Name + '\', ' +
        '\'' + req.query.Minutes + '\', ' +
        '\'' + req.query.FG + '\', ' +
        '\'' + req.query.ThreeP + '\', ' +
	 '\'' + req.query.Assists + '\', ' +
        '\'' + req.query.Rebounds + '\', ' +
        '\'' + req.query.Steals + '\', ' +
        '\'' + req.query.Fouls + '\', ' +
        '\'' + req.query.Turnovers + '\', ' +
        '\'' + req.query.Points + '\'' +
        ')';

      console.log(myQry);

      connection.query(myQry,
         function (err, result) {
            if (err) {
                     res.send('YOU CAN ONLY ADD NEW EXISTING PLAYER NO. FROM THE TEAM ROSTER TO THE GAME STATS.');
		}
            else {  res.send('PLAYER INSERTED INTO GAME STATS SUCCESSFULLY!'); }
	   });
        }
    );



//================================================================================================

// Display information about a Player when given their Player Number and allow them to edit it.
app.get('/teamroster/edit', function (req, res) {

    var myQry = 'SELECT * FROM Team_roster WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry, function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {

                // Build the HTML table from the data in the Student table
                var responseHTML = htmlHeader + '<h1>Edit Player Info.</h1>';

                responseHTML += '<form action="/teamroster/update" method="GET">';

                //Dynamic populating rows from the records returned
                if (result.length == 1) {

                    //using an inline or ternary if to replace null with an empty string, otherwise null
                    //will appear in the input field
                //    var location = (result[0].Location == null) ? '' : result[0].Location;

                    responseHTML += 'Name.... <input type="text" name="name" id="name" value="' + result[0].Name + '" /><br />' +
                        'Position. <input type="text" name="position" id="position" value="' + result[0].Position + '" /><br />' +
			'Age....... <input type="text" name="age" id="age" value="' + result[0].Age + '" /><br />' +
			'Height... <input type="text" name="height" id="height" value="' + result[0].Height + '" /><br />' +
			'Weight.. <input type="text" name="weight" id="weight" value="' + result[0].Weight + '" /><br />' +
			'College. <input type="text" name="college" id="college" value="' + result[0].College + '" /><br />' +
       
                        '<input type="hidden" name="num" id="num" value="' + result[0].Num + '" />' +
                        '<br /><input type="submit" />' +
                        '<br /></form>' +
                        htmlFooter;

                    res.send(responseHTML);
                }
                else {
                    res.send('More than one record was returned.')
                }
            }
        }
    );
});


//================================================================================================
// Display information about a Starting Lineup when given their Position Number and allow them to edit it.

app.get('/starters/edit', function (req, res) {

    var myQry = 'SELECT * FROM Starters WHERE PositionID=' + req.query.PositionID;

    console.log(myQry);

    connection.query(myQry, function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
	    var responseHTML = htmlHeader + '<h1>EDIT TEAM STARTING LINEUP</h1>';

                responseHTML += '<form action="/starters/update" method="GET">';
		if (result.length == 1) {
		  responseHTML += 'PositionID. <input type="text" name="positionid" id="positionid" value="' + result[0].PositionID + '" /><br />' +
                        'Position..... <input type="text" name="position" id="position" value="' + result[0].Position + '" /><br />' +
                        'Starter....... <input type="text" name="starter" id="starter" value="' + result[0].Starter + '" /><br />' +
                        'Second...... <input type="text" name="second" id="second" value="' + result[0].Second + '" /><br />' +
                        'Third......... <input type="text" name="third" id="third" value="' + result[0].Third + '" /><br />' +

                        '<br /><br/><input type="submit" />' +
                        '</form>' +
                        htmlFooter;

                    res.send(responseHTML);
                }
                else {
                    res.send('More than one record was returned.')
                }
            }
        }
    );
});



//================================================================================================

// Display information about a Player when given their Player Number and allow them to edit it.
app.get('/seasonstats/edit', function (req, res) {

    var myQry = 'SELECT * FROM Season_stats WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry, function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
            var responseHTML = htmlHeader + '<h1>Edit Season Stats Info.</h1>';

                responseHTML += '<form action="/seasonstats/update" method="GET">';
                if (result.length == 1) {
                  responseHTML += 'NO..... <input type="text" name="num" id="num" value="' + result[0].Num + '" /><br />' +
                        'Name. <input type="text" name="name" id="name" value="' + result[0].Name + '" /><br />' +
			'MPG.. <input type="text" name="mpg" id="mpg" value="' + result[0].MPG + '" /><br />' +
			'FGP... <input type="text" name="fgp" id="fgp" value="' + result[0].FGP + '" /><br />' +
                        '3PP.... <input type="text" name="threepp" id="threepp" value="' + result[0].ThreePP + '" /><br />' +
                        'APG.. <input type="text" name="apg" id="apg" value="' + result[0].APG + '" /><br />' +
                        'RPG.. <input type="text" name="rpg" id="rpg" value="' + result[0].RPG + '" /><br />' +
                        'SPG... <input type="text" name="spg" id="spg" value="' + result[0].SPG + '" /><br />' +
			'PPG... <input type="text" name="ppg" id="ppg" value="' + result[0].PPG + '" /><br />' +
                       
		        '<br /><input type="submit" />' +
                        '</form>' +
                    htmlFooter;
                    res.send(responseHTML);
                }
                else {
                    res.send('More than one record was returned.')
                }
            }
        }
    );
});


//================================================================================================
// Display information about a Player when given their Player Number and allow them to edit it.
app.get('/gamestats/edit', function (req, res) {

    var myQry = 'SELECT * FROM Game_stats WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry, function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
            var responseHTML = htmlHeader + '<h1>Edit Game Stats Info.</h1>';

                responseHTML += '<form action="/gamestats/update" method="GET">';
                if (result.length == 1) {
                  responseHTML += 'NO............ <input type="text" name="num" id="num" value="' + result[0].Num + '" /><br />' +
			'Name........ <input type="text" name="name" id="name" value="' + result[0].Name + '" /><br />' +
                        'Minutes.... <input type="text" name="minutes" id="minutes" value="' + result[0].Minutes + '" /><br />' +
                        'FG............ <input type="text" name="fg" id="fg" value="' + result[0].FG + '" /><br />' +
                        '3P............. <input type="text" name="threep" id="threep" value="' + result[0].ThreeP + '" /><br />' +
			'Assists...... <input type="text" name="assists" id="assists" value="' + result[0].Assists + '" /><br />' +
                        'Rebounds. <input type="text" name="rebounds" id="rebounds" value="' + result[0].Rebounds + '" /><br />' +
                        'Steals........ <input type="text" name="steals" id="steals" value="' + result[0].Steals + '" /><br />' +
                        'Fouls........ <input type="text" name="fouls" id="fouls" value="' + result[0].Fouls + '" /><br />' +
                        'Turnovers. <input type="text" name="turnovers" id="turnovers" value="' + result[0].Turnovers + '" /><br />' +
                        'Points....... <input type="text" name="points" id="points" value="' + result[0].Points + '" /><br />' +

                        '<br /><input type="submit" />' +
                        '</form>' +
                
	        htmlFooter;
		res.send(responseHTML);
                }
                else {
                    res.send('More than one record was returned.')
                }
            }
        }
    );
});



//================================================================================================


// Update a player's Team Roster Info. given their Player Number
app.get('/teamroster/update', function (req, res) {

    var myQry = 'UPDATE Team_roster SET Name="' + req.query.name + '", Position="' + req.query.position + '", Age="' + req.query.age + '", Height="' + req.query.height + '",Weight="' + req.query.weight + '", College="' + req.query.college + '" WHERE Num=' + req.query.num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM Team_roster WHERE Num = ' + req.query.num,
                    function (err, result) {
                        if (err) {
                            console.log(err);
                            res.send('An error occurred');
                        }
                        if(result.length == 1) {
                            res.send(buildUserView(result));
                        }
                        else {
                            res.send('NO PLAYER FOUND FOR THAT PLAYER NUMBER.');
                        }
                    });
            }
        }
    );
});


//================================================================================================

// Update Starters Info. given their Position ID
app.get('/starters/update', function (req, res) {

    var myQry = 'UPDATE Starters SET PositionID="' + req.query.positionid + '", Position="' + req.query.position + '", Starter="' + req.query.starter + '", Second="' + req.query.second + '",Third="' + req.query.third + '" WHERE PositionID=' + req.query.positionid;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM Starters WHERE PositionID = ' + req.query.positionid,
                    function (err, result) {
                        if (err) {
                            console.log(err);
                            res.send('An error occurred');
                        }
                        if(result.length == 1) {
                            res.send('TEAM STARTING LINEUP UPDATED SUCCESSFULLY!');
                        }
                        else {
                            res.send('NO STARTING LINEUP FOUND FOR THAT POSITION ID.');
                        }
                    });
            }
        }
    );
});


//================================================================================================

// Update a player's Season_stats Info. given their Player Number
app.get('/seasonstats/update', function (req, res) {

    var myQry = 'UPDATE Season_stats SET Num="' + req.query.num + '", Name="' + req.query.name + '",MPG="' + req.query.mpg + '", FGP="' + req.query.fgp + '", ThreePP="' + req.query.threepp + '", APG="' + req.query.apg + '",RPG="' + req.query.rpg + '", SPG="' + req.query.spg + '", PPG="' + req.query.ppg + '" WHERE Num=' + req.query.num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM Season_stats WHERE Num = ' + req.query.num,
                    function (err, result) {
                        if (err) {
                            console.log(err);
                            res.send('An error occurred');
                        }
                        if(result.length == 1) {
                          res.send('PLAYER UPDATED INTO SEASON STATS SUCCESSFULLY!');
			}
                        else {
                            res.send('NO PLAYER FOUND FOR THAT PLAYER NUMBER.');
                        }
                    });
            }
        }
    );
});


//================================================================================================
// Update a player's Game_stats Info. given their Player Number
app.get('/gamestats/update', function (req, res) {

    var myQry = 'UPDATE Game_stats SET Num="' + req.query.num + '", Name="' + req.query.name + '", Minutes="' + req.query.minutes + '", FG="' + req.query.fg + '", ThreeP="' + req.query.threep + '",Assists="' + req.query.assists + '",Rebounds="' + req.query.rebounds + '", Steals="' + req.query.steals + '", Fouls="' + req.query.fouls + '", Turnovers="' + req.query.turnovers + '", Points="' + req.query.points + '" WHERE Num=' + req.query.num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM  Game_stats WHERE Num = ' + req.query.num,
                    function (err, result) {
                        if (err) {
                            console.log(err);
                            res.send('An error occurred');
                        }
                        if(result.length == 1) {
                          res.send('PLAYER UPDATED INTO GAME STATS SUCCESSFULLY!');
			}
                        else {
                            res.send('NO PLAYER FOUND FOR THAT PLAYER NUMBER.');
                        }
                    });
            }
        }
    );
});

//================================================================================================

// Route for deleting a player record from the team roster database.
app.get('/teamroster/delete', function (req, res) {

    var myQry = 'DELETE FROM Team_roster WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send('PLAYER NO. ' + req.query.Num + ' SUCCESSFULLY DELETED.');
            }
        }
    );
});

//================================================================================================
// Route for deleting a starting lineup record from the starters database.
app.get('/starters/delete', function (req, res) {

    var myQry = 'DELETE FROM Starters WHERE PositionID=' + req.query.PositionID;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send('POSITION ID NO. ' + req.query.PositionID + ' SUCCESSFULLY DELETED.');
            }
        }
    );
});

//================================================================================================
// Route for deleting a season record from the season stats database.
app.get('/seasonstats/delete', function (req, res) {

    var myQry = 'DELETE FROM Season_stats WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send('PLAYER NO. ' + req.query.Num + ' SUCCESSFULLY DELETED..');
            }
        }
    );
});

//================================================================================================
// Route for deleting a game record from the game stats database.
app.get('/gamestats/delete', function (req, res) {

    var myQry = 'DELETE FROM Game_stats WHERE Num=' + req.query.Num;

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send('PLAYER NO. ' + req.query.Num + ' SUCCESSFULLY DELETED.');
            }
        }
    );
});


//================================================================================================

// Begin listening

app.listen(8023);
console.log("Express server listening on port %d in %s mode", app.address().port, app.settings.env);
