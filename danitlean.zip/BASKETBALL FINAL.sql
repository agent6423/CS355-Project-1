use dlean;
drop table if exists Starters;
drop table if exists Game_stats;
drop table if exists Season_stats;


DROP TABLE IF EXISTS Team_roster;
CREATE TABLE Team_roster (Num INT PRIMARY KEY AUTO_INCREMENT, Name VARCHAR(100) NOT NULL, Position VARCHAR(100) NOT NULL, Age INT NOT NULL,
Height VARCHAR(50) NOT NULL, Weight INT NOT NULL, College VARCHAR(100), UNIQUE(Num, Name));

INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (19, 'Leandro Barbosa', 'SG', 32, '6-3', 194, NULL);
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (40, 'Harrison Barnes', 'SF', 22, '6-8', 225, 'North Carolina');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (12, 'Andrew Bogut',    'C',  30, '7-0', 260, 'Utah');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (30, 'Stephen Curry',   'PG', 27, '6-3', 190, 'Davidson');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (31, 'Festus Ezeli',    'C',  25, '6-11', 265, 'Vanderbilt');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (23, 'Draymond Green',  'SF', 25, '6-7', 230, 'Michigan State');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (7,  'Justin Holiday',  'SG', 25, '6-6', 185, 'Washington');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (9,  'Andre Iguodala',  'SG', 31, '6-6', 215, 'Arizona');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (1,  'Ognjen Kuzmic',   'C',  24, '7-0', 260, NULL);
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (10, 'David Lee',       'PF', 31, '6-9', 245, 'Florida');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (34, 'Shaun Livingston','PG', 29, '6-7', 192, NULL);
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (20, 'James Michael McAdoo', 'SF', 22, '6-9', 230, 'North Carolina');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (4,  'Brandon Rush',    'SG', 29, '6-6', 220, 'Kansas');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (5,  'Marreese Speights','C', 27, '6-10', 255, 'Florida');
INSERT INTO Team_roster (Num, Name, Position, Age, Height, Weight, College) VALUE (11, 'Klay Thompson',   'SG', 25, '6-7', 215, 'Washington State');



DROP TABLE IF EXISTS Season_stats;
CREATE TABLE Season_stats (Num INT PRIMARY KEY, Name VARCHAR(100), MPG VARCHAR(10),FGP VARCHAR(10), ThreePP VARCHAR(10),
APG VARCHAR(10), RPG VARCHAR(10), SPG VARCHAR(10), PPG VARCHAR(10), UNIQUE(Num, Name), FOREIGN KEY(Num) REFERENCES Team_roster (Num) ON DELETE CASCADE ON UPDATE CASCADE);
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (19, 'Leandro Barbosa','14.5' ,'.470', '.402', '1.4', '1.3', '0.59', '6.9');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (40, 'Harrison Barnes', '28.7','.493', '.431', '1.3', '5.5', '0.73', '10.4');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (12, 'Andrew Bogut',    '23.7','.556', '.000', '2.6', '8.2', '.64', '6.2');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (30, 'Stephen Curry',   '32.8','.482', '.431', '7.9', '4.3', '2.1', '23.7');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (31, 'Festus Ezeli',    '10.7','.518', '.000', '0.2', '3.3', '0.15', '3.9');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (23, 'Draymond Green',  '31.6','.444', '.341', '3.6', '8.1', '1.61', '11.8');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (7,  'Justin Holiday',  '11.1','.395', '.316', '0.8', '1.3', '0.69', '4.2');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (9,  'Andre Iguodala',  '27.0','.482', '.355', '2.9', '3.4', '1.22', '8');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (1,  'Ognjen Kuzmic',    '4.5','.667', '.000', '0.4', '1.1', '0.13', '1.3');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (10, 'David Lee',       '18.8','.512', '.000', '1.9', '5.4', '0.72', '8.2');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (34, 'Shaun Livingston','18.7','.504', '.000', '3.4', '2.3', '0.64', '5.9');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (20, 'James Michael McAdoo', '8.8','.531', '.000', '0.1', '2.6', '0.4', '4.4');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (4,  'Brandon Rush',     '8.2','.184', '.083', '0.4', '1.2', '0.10', '0.8');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (5,  'Marreese Speights', '16.3','.495', '.214', '1', '4.4', '0.22', '10.7');
INSERT INTO Season_stats (Num, Name, MPG, FGP, ThreePP, APG, RPG, SPG, PPG) VALUE (11, 'Klay Thompson',   '32.1','.464', '.434', '2.9', '3.2', '1.13', '21.7');




DROP TABLE IF EXISTS Game_stats;
CREATE TABLE Game_stats (Num INT PRIMARY KEY, Name VARCHAR(100) NOT NULL, Minutes INT, FG VARCHAR(10), ThreeP VARCHAR(10), 
Assists INT, Rebounds INT, Steals INT, Fouls INT, Turnovers INT, Points INT, UNIQUE(Num, Name), FOREIGN KEY(Num) REFERENCES Team_roster (Num) ON DELETE CASCADE ON UPDATE CASCADE);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (19, 'Leandro Barbosa', 12, '3-6', '1-3', 1, 4, 1, 0, 1, 7);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (40, 'Harrison Barnes', 25, '0-7', '0-0', 2, 7, 0, 2, 0, 1);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (12, 'Andrew Bogut',    30, '3-5', '0-0', 5, 9, 0, 6, 2, 6);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (30, 'Stephen Curry',   36, '8-15', '4-6', 4, 1, 1, 3, 3, 27);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (31, 'Festus Ezeli',    3,  '3-3', '0-0', 0, 3, 0, 0, 1, 6);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (23, 'Draymond Green',  8,  '4-6', '1-2', 2, 4, 0, 2, 0, 11);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (7,  'Justin Holiday',  0,  '0-0', '0-0', 0, 0, 0, 0, 0, 0);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (9,  'Andre Iguodala',  29, '0-3', '0-2', 7, 1, 1, 0, 0, 6);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (1,  'Ognjen Kuzmic',   0,  '0-0', '0-0', 0, 0, 0, 0, 0, 0);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (10, 'David Lee',       30, '8-12', '0-0', 1, 7, 0, 2, 0, 17);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (34, 'Shaun Livingston', 16,'0-3', '0-0', 3, 1, 1, 1, 2, 2);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (20, 'James Michael McAdoo', 2, '0-2', '0-0', 0, 0, 0, 1, 0, 0);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (4,  'Brandon Rush',    0,  '0-0', '0-0', 0, 0, 0, 0, 0, 0);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (5,  'Marreese Speights', 15,'5-9', '0-0', 1, 2, 1, 2, 0, 13);
INSERT INTO Game_stats (Num, Name, Minutes,FG, ThreeP, Assists, Rebounds, Steals, Fouls, Turnovers, Points) VALUE (11, 'Klay Thompson',   34, '8-21', '3-7', 4, 8, 1, 2, 1, 25);


DROP TABLE IF EXISTS Starters;
CREATE TABLE Starters (PositionID INT PRIMARY KEY NOT NULL, Position VARCHAR(100) NOT NULL, Starter VARCHAR(100) NOT NULL, Second VARCHAR(100), Third VARCHAR(100),
UNIQUE (PositionID, Position, Starter));

INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUE (1,'PG','Stephen Curry','Shaun Livingston','Leandro Barbosa');
INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUE (2,'SG','Klay Thompson','Brandon Rush','Justin Holiday');
INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUE (3,'SF','Harrison Barnes','Andre Iguodala', NULL);
INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUE (4,'PF','Draymond Green','David Lee','Marreese Speights');
INSERT INTO Starters (PositionID, Position, Starter, Second, Third) VALUE (5,'C','Andrew Bogut','Festus Ezeli','Ognjen Kuzmic');






